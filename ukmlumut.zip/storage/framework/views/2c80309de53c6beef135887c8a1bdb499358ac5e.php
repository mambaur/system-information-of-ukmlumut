<?php $__env->startSection('title', 'Sukses!'); ?>

<?php $__env->startSection('sub-title', 'Terimakasih'); ?>

<?php $__env->startSection('description'); ?>
    <?php echo e(session('status')); ?>

    <a class="d-block mt-3" target="_blank" href="/user/cetak?bukti=<?php echo e(session('id')); ?>"><button class="p-2 btn btn-white"><i class="fa fa-print"></i> <?php echo e(session('cetak')); ?></button></a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukmlumut\resources\views/user/success/index.blade.php ENDPATH**/ ?>