<?php $__env->startSection('title', 'Pengaturan UKM LUMUT'); ?>

<?php $__env->startSection('container'); ?>
<?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
        <i class="fa fa-check mx-2"></i>
        <strong>Sukses!</strong> <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
<!-- / .main-navbar -->
<div class="main-content-container container-fluid px-4">
<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Overview</span>
    <h3 class="page-title">Pengaturan</h3>
  </div>
</div>
<!-- End Page Header -->
<div class="row">
    <div class="col-lg-8 col-md-12 col-sm-12 mb-4">
        <div class="card card-small">
          <div class="card-body p-0">
            <ul class="list-group list-group-small list-group-flush">
              <li class="list-group-item d-flex px-3">
                <span class="text-semibold text-fiord-blue">Peminjaman Alat</span>
                <span class="ml-auto text-right text-semibold text-reagent-gray">
                    <div class="custom-control custom-toggle custom-toggle-sm mb-1">

                      <form action="/admin/pengaturan/peminjaman/<?php echo e($peminjaman->id); ?>" id="peminjaman-form" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>
                        <input type="checkbox" id="peminjaman" name="peminjaman" class="custom-control-input" <?php echo e($peminjaman->value ? 'checked' : ''); ?>>
                        <label class="custom-control-label" for="peminjaman"></label>
                      </form>


                    </div>
                </span>
              </li>
              <li class="list-group-item d-flex px-3">
                <span class="text-semibold text-fiord-blue">Pendaftaran CA</span>
                <span class="ml-auto text-right text-semibold text-reagent-gray">
                    <div class="custom-control custom-toggle custom-toggle-sm mb-1">

                      <form action="/admin/pengaturan/pendaftaran/<?php echo e($pendaftaran->id); ?>" method="post" id="pendaftaran-form">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>
                        <input type="checkbox" id="pendaftaran" name="pendaftaran" class="custom-control-input" <?php echo e($pendaftaran->value ? 'checked' : ''); ?>>
                        <label class="custom-control-label" for="pendaftaran"></label>
                      </form>

                    </div>
                </span>
              </li>
            </ul>
          </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  var peminjamanCheck = document.getElementById('peminjaman');
  peminjamanCheck.addEventListener('change', (event)=>{
    document.getElementById('peminjaman-form').submit();
  });
  
  var pendaftaranCheck = document.getElementById('pendaftaran');
  pendaftaranCheck.addEventListener('change', (event)=>{
    document.getElementById('pendaftaran-form').submit();
  });
</script>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', ['menu' => 'pengaturan'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukmlumut\resources\views/admin/pengaturan/index.blade.php ENDPATH**/ ?>