<?php $__env->startSection('title', 'Daftar Admin Sistem Informasi UKM LUMUT'); ?>

<?php $__env->startSection('container'); ?>
<?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
        <i class="fa fa-check mx-2"></i>
        <strong>Sukses!</strong> <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>

<!-- / .main-navbar -->
<div class="main-content-container container-fluid px-4">
    <!-- Page Header -->
    <div class="page-header row no-gutters py-4">
        <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
            <span class="text-uppercase page-subtitle">Overview</span>
            <h3 class="page-title">Kelola Akun Admin</h3>
        </div>
    </div>
    <div class="row">
        <!-- List Admin -->
        <div class="col-lg col-md-12 col-sm-12 mb-4">
            <div class="card card-small blog-comments">
                <div class="card-header border-bottom d-flex justify-content-between">
                    <h6 class="m-0">Daftar akun admin</h6>
                    <div><a href="<?php echo e(url('admin/kelola-admin/tambah')); ?>"><button class="btn btn-white">+ Tambah Admin</button></a></div>
                </div>
                <div class="card-body p-0">
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="blog-comments__item d-flex p-3">
                            <div class="blog-comments__avatar mr-3">
                            <img src="/assets/admin/images/akun/<?php echo e($item->image); ?>" alt="User avatar" /> </div>
                            <div class="blog-comments__content">
                            <div class="blog-comments__meta text-muted">
                                <a class="text-secondary" href="#"><?php echo e($item->name.' '.$item->nama_belakang); ?></a> -
                                <a class="text-secondary" href="#"><?php echo e($item->jabatan); ?></a>
                                <span class="text-muted"><?php echo e($item->updated_at ? '– Updated at '.$item->updated_at : ''); ?></span>
                            </div>
                            <p class="m-0 my-1 mb-2 text-muted"><?php echo e($item->email); ?></p>
                            <div class="blog-comments__actions">
                                <div class="btn-group btn-group-sm">
                                <a href="/admin/kelola-admin/edit/<?php echo e($item->id); ?>">
                                    <button type="button" class="btn btn-white">
                                        <span class="text-success">
                                        <i class="material-icons">edit</i>
                                        </span> Edit 
                                    </button>
                                </a>
                                <form class="d-inline-block" method="post" action="/admin/kelola-admin/<?php echo e($item->id); ?>">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <?php if($item->role === 'Master' && $item->email === 'ukm.lumut@polije.ac.id'): ?>
                                        <button type="button" class="btn btn-white">
                                            <span class="text-secondary">
                                            <i class="material-icons">clear</i>
                                            </span> Hapus 
                                        </button>
                                    <?php else: ?>
                                        <button type="submit" class="btn btn-white" onclick="return confirm('Apakah anda yakin ingin menghapus data <?php echo e($item->name); ?>?');">
                                            <span class="text-danger">
                                            <i class="material-icons">clear</i>
                                            </span> Hapus 
                                        </button>
                                    <?php endif; ?>
                                    
                                </form>
                                </div>
                            </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="card-footer border-top">
                <div class="row">
                    <div class="col text-center view-report d-flex justify-content-center">
                        <?php echo e($user->links()); ?>

                    </div>
                </div>
                </div>
            </div>
        </div>
        <!-- End Discussions Component -->
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', ['menu' => 'kelola_admin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukmlumut\resources\views/admin/akun/master/index.blade.php ENDPATH**/ ?>