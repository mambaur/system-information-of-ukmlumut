<?php $__env->startSection('title', 'Data Alumni UKM LUMUT'); ?>

<?php $__env->startSection('container'); ?>
<?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
        <i class="fa fa-check mx-2"></i>
        <strong>Sukses!</strong> <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>

<div class="main-content-container container-fluid px-4">
    <!-- Page Header -->
    <div class="page-header row no-gutters py-4">
      <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
        <span class="text-uppercase page-subtitle">Overview</span>
        <h3 class="page-title">Data Alumni (<?php echo e(count($alumni)); ?>)</h3>
      </div>
    </div>

    <div class="d-flex justify-content-between">
      <a href="/admin/alumni/cetak" target="_blank">
        <button class="btn btn-white mb-2"><i class="material-icons">print</i> Cetak semua data alumni</button>
      </a>
      <div>
        <a href="/admin/alumni/kategori?bidang=Lukis">
          <button class="btn btn-white mb-2">Lukis</button>
        </a>
        <a href="/admin/alumni/kategori?bidang=Musik">
          <button class="btn btn-white mb-2">Musik</button>
        </a>
        <a href="/admin/alumni/kategori?bidang=Tari">
          <button class="btn btn-white mb-2">Tari</button>
        </a>

        <div class="d-inline-block">
          <span class="text-muted ml-3">Filter by year</span>
          <select name="year" id="year" class="form-control">
            <option value="" hidden selected>Pilih tahun</option>
            <?php for($i = 0; $i < 35; $i++): ?>
                <option name="<?php echo e(1996+$i); ?>"><?php echo e(1996+$i); ?></option>
            <?php endfor; ?>
          </select>
        </div>
      </div>
    </div>

    <div class="row">
        <?php $__currentLoopData = $alumni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-12 col-sm-12 mb-4">
          <div class="card card-small card-post card-post--aside card-post--1">
            <div class="card-post__image" style="background-image: url('/assets/admin/images/anggota/<?php echo e($item->foto); ?>');">
              <a href="#" class="card-post__category badge badge-pill badge-info"><?php echo e($item->bidang); ?></a>
              <div class="card-post__author d-flex">
              </div>
            </div>
            <div class="card-body">
              <h5 class="card-title">
                <a class="text-fiord-blue" href="#"><?php echo e($item->nama_anggota); ?></a>
              </h5>
              <p class="card-text mb-3"><?php echo e($item->jurusan); ?>, <?php echo e($item->alamat); ?> - <?php echo e($item->telp); ?></p>
              <span class="text-muted">Angkatan <?php echo e($item->angkatan); ?> - </span>

              <a href="/admin/anggota/edit/<?php echo e($item->id); ?>">
                <button class="btn btn-white"><i class="material-icons">edit</i> Edit</button>
              </a>
              <form class="d-inline-block" method="post" action="/admin/anggota/<?php echo e($item->id); ?>">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-sm btn-white" onclick="return confirm('Apakah anda yakin ingin menghapus data <?php echo e($item->nama_anggota); ?>?');">
                  <i class="material-icons">close</i> Hapus
                </button>
              </form>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <?php if(!count($alumni)): ?>
      <div class="row mx-auto d-flex justify-content-center">
        <p class="text-center text-muted mt-5">Data alumni tidak ditemukan.</p>
      </div>
      <?php endif; ?>
    
    <?php echo e($alumni->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
      var url = '/admin/alumni/kategori';
      var select = document.getElementById('year');
      select.addEventListener('change', function(){
        var year = select.options[select.selectedIndex].text;
        url = url + '?year='+year;
        window.location = url;
      });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', ['menu' => 'alumni'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukmlumut\resources\views/admin/alumni/index.blade.php ENDPATH**/ ?>