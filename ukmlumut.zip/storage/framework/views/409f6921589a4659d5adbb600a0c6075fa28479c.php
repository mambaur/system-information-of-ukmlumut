<?php $__env->startSection('title', 'Recruitmen UKM LUMUT'); ?>

<?php $__env->startSection('container'); ?>
<?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
        <i class="fa fa-check mx-2"></i>
        <strong>Sukses!</strong> <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
<!-- / .main-navbar -->
<div class="main-content-container container-fluid px-4">
<!-- Page Header -->
<div class="page-header row no-gutters py-4">
  <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
    <span class="text-uppercase page-subtitle">Overview</span>
    <h3 class="page-title">Data Pendaftaran anggota</h3>
  </div>
</div>
<!-- End Page Header -->
<div class="row">
    <div class="col-lg-8 col-md-12 col-sm-12 mb-4">
      <div class="mb-2">
        <a href="/admin/recruitmen/cetak-bidang?nama=Lukis" target="_blank"><button class="btn btn-white"><i class="material-icons">print</i> Cetak CA Lukis (<?php echo e($lukis); ?>)</button></a>
        <a href="/admin/recruitmen/cetak-bidang?nama=Musik" target="_blank"><button class="btn btn-white"><i class="material-icons">print</i> Cetak CA Musik (<?php echo e($musik); ?>)</button></a>        
        <a href="/admin/recruitmen/cetak-bidang?nama=Tari" target="_blank"><button class="btn btn-white"><i class="material-icons">print</i> Cetak CA Tari (<?php echo e($tari); ?>)</button></a>        
      </div>
      <div class="card card-small">
        <div class="card-body p-0">
          <ul class="list-group list-group-small list-group-flush">
              <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li class="list-group-item d-flex">
                  <a href="/admin/anggota/edit/<?php echo e($item->id); ?>" class="d-block">
                      <span class="text-semibold text-fiord-blue"><?php echo e($item->nama_anggota); ?> (<?php echo e($item->bidang); ?>)</span> <br/>
                      <span class="text-fiord-blue"><?php echo e($item->kota); ?></span> 
                  </a>
                  <a href="/admin/anggota/<?php echo e($item->id); ?>" class="d-block ml-2" target="_blank">
                      <i class="material-icons">visibility</i> Lihat
                  </a>
                  <span class="ml-auto text-right text-semibold text-reagent-gray">
                      <form method="post" class="d-inline-block" action="/admin/recruitmen/<?php echo e($item->id); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>
                        <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Apakah anda yakin ingin menerima <?php echo e($item->nama_anggota); ?> sebagai Anggota Baru?');">Terima</button>
                      </form>
                      <form class="d-inline-block" method="post" action="/admin/recruitmen/<?php echo e($item->id); ?>">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-sm btn-white" onclick="return confirm('Apakah anda yakin ingin menolak <?php echo e($item->nama_anggota); ?>?');">
                          Tolak
                        </button>
                      </form>
                  </span>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      </div>
      <?php echo e($anggota->links()); ?>

    </div>
    <?php if($asal): ?>
    <div class="col-lg-4 col-md-12 col-sm-12 mb-4">
        <div class="mb-2">
            <a href="/admin/recruitmen/cetak-presensi" target="_blank"><button class="btn btn-white"><i class="material-icons">print</i> Cetak presensi</button></a>
            <a href="/admin/recruitmen/cetak-semua" target="_blank"><button class="btn btn-white"><i class="material-icons">print</i> Cetak semua data CA</button></a>        
        </div>
        <div class="card card-small">
          <div class="card-body p-0">
            <ul class="list-group list-group-small list-group-flush">
                <?php $__currentLoopData = $asal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item d-flex px-3">
                  <span class="text-semibold text-fiord-blue"><?php echo e($keyAsal[$loop->iteration-1]); ?></span>
                  <span class="ml-auto text-right text-semibold text-reagent-gray">
                      <?php echo e($item); ?>

                  </span>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php if(!count($anggota)): ?>
    <div class="text-center">Belum ada anggota yang mendaftar.</div>
<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', ['menu' => 'recruitmen'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukmlumut\resources\views/admin/recruitmen/index.blade.php ENDPATH**/ ?>