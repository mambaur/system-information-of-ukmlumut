<?php $__env->startSection('title', 'Peminjaman Perlengkapan UKM LUMUT'); ?>

<?php $__env->startSection('container'); ?>
<?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
        <i class="fa fa-check mx-2"></i>
        <strong>Sukses!</strong> <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
<!-- / .main-navbar -->
<div class="main-content-container container-fluid px-4">
    <!-- Page Header -->
    <div class="page-header row no-gutters py-4">
    <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
        <span class="text-uppercase page-subtitle">Overview</span>
        <h3 class="page-title">Peminjaman <?php echo e($tipe); ?></h3>
    </div>
    </div>
    <!-- End Page Header -->
    <div class="row mb-5">
        <div class="col-lg">
            <div class="card card-small">
                <div class="card-body p-0">
                  <ul class="list-group list-group-small list-group-flush">
                      <?php $__currentLoopData = $peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li class="list-group-item">
                        <div class="d-inline-block d-flex justify-content-between">
                            <a href="#" class="d-inline-block ml-2">
                                <?php if($item->status === "ditolak"): ?>
                                <span class="text-semibold text-danger p-0 m-0 lead">
                                    <i class="material-icons">error_outline</i> 
                                    <?php echo e($item->acara); ?> (Ditolak)
                                </span>
                                <?php else: ?>    
                                <span class="text-semibold text-success p-0 m-0 lead">
                                    <i class="material-icons">error_outline</i> 
                                    <?php echo e($item->acara); ?>

                                </span>
                                <?php endif; ?>
                                
                                <br/>
                                <span class="text-fiord-blue">
                                    <?php echo e($item->nama_peminjam); ?> (<?php echo e($item->telp); ?>)- 
                                    <span class="badge rounded-pill bg-secondary text-white">
                                        <?php echo e($item->instansi); ?></span> |  
                                    Tanggal pinjam : <span class="text-primary"><?php echo e($item->tanggal_pinjam); ?></span> | 
                                    Tanggal kembali : <span class="text-primary"><?php echo e($item->tanggal_kembali); ?></span>
                                    <div class="">
                                        <?php echo e($item->keterangan); ?>

                                    </div>
                                </span> 
                            </a>
                            <div>
                                <span class="text-muted mr-2"><?php echo e($item->created_at); ?></span>
                                <form class="d-inline-block" action="/admin/perlengkapan/konfirmasi-peminjaman/<?php echo e($item->id); ?>" method="post">
                                    <input type="hidden" value="<?php echo e($item->kode_pinjam); ?>" name="kode_pinjam">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('patch'); ?>
                                    <?php if($item->status === "request"): ?>
                                        <button type="submit" name="submit" value="konfirmasi" class="btn btn-success">Konfirmasi</button>
                                        <button type="submit" name="submit" value="tolak" class="btn btn-white">Tolak</button>
                                    
                                    <?php elseif($item->status === "dipinjam"): ?>
                                        <button type="submit" name="submit" value="pengembalian" class="btn btn-success">Konfirmasi Pengembalian</button>
                                    <?php elseif($item->status === "terlambat"): ?>
                                        <button type="submit" name="submit" value="pengembalian" class="btn btn-success">Konfirmasi Pengembalian</button>
                                        <button type="submit" name="submit" value="hapus" class="btn btn-white">Hapus</button>
                                    <?php else: ?>
                                        <button type="submit" name="submit" value="hapus" class="btn btn-white">Hapus</button>
                                    <?php endif; ?>
                                </form>
                                
                            </div>
                        </div>
                        <div class="mt-3">
                            <?php $__currentLoopData = $detail_peminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item_detail->peminjamans_kode_pinjam === $item->kode_pinjam): ?>
                                <div class="row ml-5 mt-1">
                                    <img src="/assets/admin/images/perlengkapan/<?php echo e($item_detail->gambar); ?>" style="height:40px" alt="">
                                    <span class="ml-2">
                                        <div class="text-dark"><a target="_blank" href="/admin/perlengkapan/<?php echo e($item_detail->id); ?>"><?php echo e($item_detail->nama_barang); ?></a></div>
                                        <div class="text-muted">Kondisi : <?php echo e($item_detail->kondisi); ?></div>
                                    </span>
                                </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                      </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
            </div>
        </div>
        <?php echo e($peminjaman->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', ['menu' => 'perlengkapan'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukmlumut\resources\views/admin/perlengkapan/peminjaman.blade.php ENDPATH**/ ?>