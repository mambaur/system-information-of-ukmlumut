<?php $__env->startSection('title', 'Kritik & Saran untuk UKM LUMUT'); ?>

<?php $__env->startSection('sub-title', 'Kritik dan Saran untuk UKM LUMUT'); ?>

<?php $__env->startSection('description', 'Isikan kritik dan saran kamu untuk UKM LUMUT menjadi lebih baik, identitas anda 100% akan dirahasiakan'); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
        <i class="fa fa-check mx-2"></i>
        <strong>Sukses!</strong> <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
<!-- SECTIONS
    ================================================== -->
    <section id="contact-info">
        <div class="container mb-5" id="container-section">
            <form action="/kritik-dan-saran" method="post">
                <?php echo csrf_field(); ?>
                <div class="row justify-content-center">
                    <div class="col-lg col-sm-6 col-md-6">
                        <div class="form-group">
                            <label for="pesan"><h2>Kritik & Saran Anda!</h2></label>
                            <textarea class="form-control <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pesan" id="pesan" rows="6" placeholder="Masukkan kritik dan saran anda disini..."><?php echo e(old('pesan')); ?></textarea>
                            <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <button type="submit" class="btn btn-primary mb-5">Kirim</button>
                    </div>
                </div>
            </form>
            
        </div>
    </section>
    <div id="editor"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.5.3/jspdf.min.js"></script>

<script>
    // var source = document.getElementById('container');
    function genPDF() {
        var doc = new jsPDF();
        var specialElementHandlers = {
            '#editor': function (element, renderer) {
                return true;
            }
        };
        doc.fromHTML($('#container-section').html(), 15, 15, {
            'width': 170,
                'elementHandlers': specialElementHandlers
        });
        doc.save('sample-file.pdf');
        }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukmlumut\resources\views/user/pesan/index.blade.php ENDPATH**/ ?>