<?php $__env->startSection('title', 'Log user login UKM LUMUT'); ?>

<?php $__env->startSection('container'); ?>
<?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
        <i class="fa fa-check mx-2"></i>
        <strong>Sukses!</strong> <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
<!-- / .main-navbar -->
<div class="main-content-container container-fluid px-4">
    <!-- Page Header -->
    <div class="page-header row no-gutters py-4">
        <div class="col-12 col-sm-4 text-center text-sm-left mb-0">
            <span class="text-uppercase page-subtitle">Overview</span>
            <h3 class="page-title">Log user login</h3>
        </div>
    </div>
    <div class="row">
        <div class="col-lg table-responsive">
            <table class="table table-dark">
                
                </thead>
                <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="d-flex">
                      <th class="col-2"><?php echo e($item->created_at); ?></th>
                      <td class="col-7"><?php echo e($item->nama_user); ?></td>
                      <td class="col-1"><?php echo e($item->email); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($user->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.main', ['menu' => 'log_user'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukmlumut\resources\views/admin/log/index.blade.php ENDPATH**/ ?>