<?php $__env->startSection('title', $artikel->judul); ?>

<?php $__env->startSection('sub-title', $artikel->judul); ?>

<?php $__env->startSection('description', $artikel->created_at); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('status')): ?>
    <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
        <i class="fa fa-check mx-2"></i>
        <strong>Sukses!</strong> <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>

<!-- SECTIONS ===================== -->
<section class="section" id="single-project">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="project-lg-img">
                            <img src="/assets/admin/images/artikel/<?php echo e($artikel->image); ?>" alt="" class="img-fluid w-100">
                        </div>
                    </div>
                </div>

                <div class="row justify-content-center">
                    <div class="col-lg">
                        <div class="project-single-info">
                            <p><?php echo $artikel->konten; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout.post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ukmlumut\resources\views/user/tari/detail.blade.php ENDPATH**/ ?>