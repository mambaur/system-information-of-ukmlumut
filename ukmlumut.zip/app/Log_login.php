<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Log_login extends Model
{
    protected $fillable = ['nama_user', 'email'];
}
